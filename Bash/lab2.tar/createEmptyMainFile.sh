#!/bin/sh
cat jerry_861208558.txt > main.cc
echo "int main(int argc, const char** argv)" >> main.cc
echo "{ }" >> main.cc
