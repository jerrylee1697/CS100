#ifndef __COMMAND_CLASS__
#define __COMMAND_CLASS__

#include "composite.h"

class Command {
	protected:
		Base* root;
	
	public:
		Command() {}; 
		Command(Base* ) {};
		double execute() {
			return root->evaluate();
		};
		Base* get_root() {
			return root;
		};
};

class OpCommand : public Command {
	//OpCommand Code Here
	public:
		OpCommand(int b) { 
			root = new Op(b);
		}
	
};

class AddCommand : public Command {
	//AddCommand Code Here
	public:
		AddCommand(Command* a, double b) : Command() { 
			Base* temp = new Op(b);
			this->root = new Add(a->get_root(), temp);
		};
	
};

class SubCommand : public Command {
	//SubCommand Code Here
	public:
		SubCommand(Command* a, int b) { 
			root = new Sub(new Op(a->execute()), new Op(b)); 
		}
	
};

class MultCommand : public Command {
	//MultCommand Code Here
	public:
		MultCommand(Command* a, int b) { 
			root = new Mult(new Op(a->execute()), new Op(b)); 
		}
	
};

class SqrCommand : public Command {
	//SqrCommand Code Here
	public:
		SqrCommand(Command* b) { 
			root = new Sqr(new Op(b->execute())); 
		}
		
};

#endif //__COMMAND_CLASS__
