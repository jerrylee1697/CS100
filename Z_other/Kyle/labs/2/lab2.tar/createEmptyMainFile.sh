#!/bin/sh
touch main.cc
echo $(cat kyle_861220581.txt) "
int main(int argc, const char** argv)
{ }" > main.cc
