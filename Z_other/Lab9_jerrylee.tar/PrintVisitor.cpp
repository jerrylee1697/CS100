#include "PrintVisitor.h"
#include <cstring>

PrintVisitor::PrintVisitor(){}

void PrintVisitor::rootNode() { //For visiting a root node (do nothing)

}		
void PrintVisitor::sqrNode() {
	output.append("^2");
}
void PrintVisitor::multNode() {
	output.append("*");
}	
void PrintVisitor::subNode() {
	output.append("-");
}		
void PrintVisitor::addNode() {
	output.append("+");
}
void PrintVisitor::opNode(Op* op) {
	output.append(to_string(op->evaluate()));
}	//For visiting a leaf node

void PrintVisitor::execute() {
	for(unsigned int i = 0; i < output.size(); ++i) {
		cout << output.at(i) << " ";
	} cout << endl;
}		
